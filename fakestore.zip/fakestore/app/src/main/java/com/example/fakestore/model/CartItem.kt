package com.example.fakestore.model

data class CartItem(
    val product: Product,
    var quantity: Int
)